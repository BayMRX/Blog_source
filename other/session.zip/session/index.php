<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head> 
<form action="" method="post">			
<input type="text" name="xss"/>
<input type="submit" value="提交"/>
</form>
<?php
if(is_array($_GET)&&count($_GET)>0)//先判断是否通过get传值了
    {
        if(isset($_GET["user"])){
			session_start();
			echo 'session_id:'.session_id().'<br>';
			echo '用户名：'.htmlspecialchars($_GET["user"], ENT_QUOTES).'<br>';
			echo '密文：'.htmlspecialchars($_SESSION["mi"], ENT_QUOTES).'<br>';
		}
}

$xss=@$_POST['xss'];			//提取xxs参数，将值赋给变量xss
mysql_connect("localhost","root","root");		//连接MySQL
mysql_select_db("cms");						//使用cms数据库
if($xss!==null){						//如果有提交值，则将其写入数据库
	$sql="insert into temp(payload) values('".$xss."')";
	$result=mysql_query($sql);
	if($result!==1){
		echo "保存失败";
	}
}
$sql_1="select * from temp";				//查询temp表中的所有内容
$result_1=mysql_query($sql_1);
echo "<table>";
echo "<tr><td>id</td><td>payload</td></tr>";
while($row = mysql_fetch_row($result_1)) 
	echo "<tr><td>$row[0]</td><td>$row[1]</td></tr>";   //显示数据
echo "</table>";

?>
<body>
<form action="login.php" method="post">
账户: <input type="text" name="username"><br>
密码: <input type="password" name="password"/><br>
密文: <input type="text" name="mi"/><br>
<input type="hidden" name="login" value="true">
<input type="submit">
</form>

</body>
</html>