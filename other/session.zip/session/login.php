<?php 
 session_start();
 if (isset($_POST["login"]))
 {
 $link = mysql_connect("localhost", "root", "root")
 or die("无法建立MySQL数据库连接：" . mysql_error());
 mysql_select_db("cms") or die("无法选择MySQL数据库");
 if (!get_magic_quotes_gpc())
 {
 $query = "select * from member where username='" . addslashes($_POST["username"]) ."' and password='" . addslashes($_POST["password"]) . "'";
 }
 else
 {
 $query = "select * from member where username='" . $_POST["username"] ."' and password='" . $_POST["password"] . "'";
 }
 $result = mysql_query($query)
 or die("执行MySQL查询语句失败：" . mysql_error());
 $match_count = mysql_num_rows($result);
 if ($match_count)
 {
 $_SESSION["username"] = $_POST["username"];
 $_SESSION["password"] = $_POST["password"];
 $_SESSION["mi"] = $_POST['mi'];
 mysql_free_result($result);
 mysql_close($link);
 header("Location: index.php?user=" .$_POST["username"]);
 }
 }
?>