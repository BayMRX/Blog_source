rm -rf crypto-config channel-artifacts && mkdir crypto-config
../../fabric-samples/bin/cryptogen generate --config=crypto-config.yaml
../../fabric-samples/bin/configtxgen -profile OrdererGenesis -outputBlock ./channel-artifacts/genesis.block -channelID fabric-channel
../../fabric-samples/bin/configtxgen -profile ChannelOne -outputCreateChannelTx ./channel-artifacts/channel1.tx -channelID mychannel1
../../fabric-samples/bin/configtxgen -profile ChannelTwo -outputCreateChannelTx ./channel-artifacts/channel2.tx -channelID mychannel2
../../fabric-samples/bin/configtxgen -profile ChannelThree -outputCreateChannelTx ./channel-artifacts/channel3.tx -channelID mychannel3

../../fabric-samples/bin/configtxgen -profile ChannelOne -outputAnchorPeersUpdate ./channel-artifacts/Org1MSPanchors_ChannelOne.tx -channelID mychannel1 -asOrg Org1MSP
../../fabric-samples/bin/configtxgen -profile ChannelOne -outputAnchorPeersUpdate ./channel-artifacts/Org3MSPanchors_ChannelOne.tx -channelID mychannel1 -asOrg Org3MSP
../../fabric-samples/bin/configtxgen -profile ChannelTwo -outputAnchorPeersUpdate ./channel-artifacts/Org2MSPanchors_ChannelTwo.tx -channelID mychannel2 -asOrg Org2MSP
../../fabric-samples/bin/configtxgen -profile ChannelTwo -outputAnchorPeersUpdate ./channel-artifacts/Org3MSPanchors_ChannelTwo.tx -channelID mychannel2 -asOrg Org3MSP
../../fabric-samples/bin/configtxgen -profile ChannelThree -outputAnchorPeersUpdate ./channel-artifacts/Org3MSPanchors_ChannelThree.tx -channelID mychannel3 -asOrg Org3MSP
./ccp-generate.sh
rm -rf ../wallet* ../keystore