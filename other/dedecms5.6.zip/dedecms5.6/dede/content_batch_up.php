<?php
require_once(dirname(__FILE__).'/config.php');
require_once(DEDEINC.'/typelink.class.php');
include DedeInclude('templets/content_batch_up.htm');

?>